<h1 align="center">そのメイキー <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>BOT WHATSAPP</h1>

<p align="center">
<img src="https://f.top4top.io/p_18972zu6n0.png" width="100%" alt="API Giphy logo"/>
</p>

- 🌱 I’m currently learning **nothing**.

- 👀 I m currently focusing on **JavaScript**.
 

<p align="center">
  <img src="https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript" />
  <img src="https://img.shields.io/badge/-Node.js-black?style=flat-square&logo=Node.js" />
  <img src="https://img.shields.io/badge/-HTML5-black?style=flat-square&logo=html5&logoColor=e34f26" />
  <img src="https://img.shields.io/badge/-CSS3-black?style=flat-square&logo=css3&logoColor=1572b6" />
  <img src="https://img.shields.io/badge/-Git-black?style=flat-square&logo=git" />
  <img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> <br>
  <img src="https://img.shields.io/badge/-Python-black?style=flat-square&logo=python" />
  <img src="https://img.shields.io/badge/-React-black?style=flat-square&logo=react" />
  <img src="https://img.shields.io/badge/-Redux-black?style=flat-square&logo=redux" />
  <img src="https://img.shields.io/badge/-Windows-black?style=flat-square&logo=windows" />
  <img src="https://img.shields.io/badge/-VS_Code-black?style=flat-square&logo=visual-studio-code" />
  <img src="https://img.shields.io/badge/-SQLite3-black?style=flat-square&logo=sqlite" />
</p>

<p align="center">
  <a href="https://github.com/FDLBOT"><img src="https://github-readme-stats.vercel.app/api?username=FDLBOT&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&icon_color=fff&hide_border=true&show_icons=true" /></a>
</p>

<p align="center">
  <a href="https://github.com/FDLBOT"><img src="https://github-readme-stats.vercel.app/api/top-langs?username=FDLBOT&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&hide_border=true&show_icons=true&layout=compact" /></a>
</p>

<p align="center">
  <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=FDLBOT&theme=onedark" /></a>
</p>

<p align="center">
   <img src="https://github-readme-streak-stats.herokuapp.com/?user=FDLBOT" />
</p>

<p align="center">
  <a href="https://youtube.com/channel/UCp5bH8pqBjqE3uqt3IYJFyQ"><img src="https://img.shields.io/badge/YouTube-FDLBOT-ff0000?style=for-the-badge&logo=youtube&logoColor=ff0000&link=https://www.youtube.com/channel/UCp5bH8pqBjqE3uqt3IYJFyQ" /></a>
  <a name=hendra759&label=VIEWS&style=flat-square&color=orange" />
 </p>

## Features

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Send Photo with Caption          |
|       ✅       | Reply A Photo                    |
|       ✅       | Reply A Video or GIF             |
|       ✅       | Send Video or GIF with Caption   |
|       ✅       | Reply A Sticker ( sticker to image ) |

| Maker Menu |            Feature          |
| :-----------: | :--------------------------------: |
|       ✅        |   Summer                   |
|       ✅        |   Ninja Logo                   |
|       ✅        |   Lion Logo                  |
|       ✅        |   Joker Logo                 |
|       ✅        |   Glitch                          |
|       ✅        |   Wolf Logo                    |
|       ✅        |   Qr Code                      |
|       ✅        |   Blood                             |
|       ✅        |   Neon Text                        |
|       ✅        |   Green Neon                   |
|       ✅        |   Drop Water                      |
|       ✅        |   Metal Dark                    |
|       ✅        |   Avengers                        |
|       ✅        |   Lava                               |
|       ✅        |   Sand Write                   |

| Media  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Writing feature 				|
|       ✅        |   What Anime Is This 			|
|       ✅        |   Url2Img                             |
|       ✅        |   Simsimi		                |
|       ✅        |   Ytmp3                              |
|       ✅        |   Ytmp4                            |
|       ✅        |   Joox                                 |
|       ✅        |   Igstalk                                |
|       ✅        |   Pinterest                        |
|       ✅        |   Brainly                             |
|       ✅        |   Bitly                                |
|       ✅        |   Buy limit                           |
|       ✅        |   Dompet                           |
|       ✅        |   Transfer                              |
|       ✅        |   Berita Hoax                      |

| Fun Menu   |            Feature          |
| :-----------: | :--------------------------------: |
|       ✅        |   Peluk                          |
|       ✅        |   Cium                                |
|       ✅        |   Nangis                              |
|       ✅        |   Happy Mood                   |
|       ✅        |   Mod Droid                         |
|       ✅        |   Tampar                           |
|       ✅        |   Slap                                |
|       ✅        |   Rate                               |
|       ✅        |   Apakah                             |
|       ✅        |   Kapankah                              |
|       ✅        |   Bisakah                              |
|       ✅        |   Mining                              |
|       ✅        |   Quotes                              |
|       ✅        |   Toxic                                |
|       ✅        |   Next                                |

| Group  |                     Feature               |
| :-----------: | :--------------------------------: |
|       ✅        |   Tagall/Mentionall member       |
|       ✅        |   Kick Member Group	             |
|       ✅        |   Add Member Group	             |
|       ✅        |   Get List Admins Group          |
|       ✅        |   Group List                              |
|       ✅        |   Setpp ( Group )                  |
|       ✅        |   Setname ( Group )                |
|       ✅        |   Setdesc ( Group )                |
|       ✅        |   Leveling                             |
|       ✅        |   Promote                      |
|       ✅        |   Demote                          |
|       ✅        |   Buka/Tutup Group                |
|       ✅        |   Hidetag                            |
|       ✅        |   Welcome                           |
|       ✅        |   Link Gc                        |
|       ✅        |   Level                                 |
|       ✅        |   Simi                           |

| Owner Bot  |                     Feature           |
| :-----------: | :--------------------------------: |
|       ✅        |   Set Prefix                     |
|       ✅        |   Broadcast                      |
|       ✅        |   Clear All Chats                |
|       ✅        |   Set pp bot                      |
|       ✅        |   Clear All Chats                |
|       ✅        |   Block/Unblock                |
|       ✅        |   Setreply ( Fake Reply )         |
|       ✅        |   Clone                           |
|       ✅        |   Broadcast                |

## Special Thanks to
* [`adiwajshing/Baileys`](https://github.com/adiwajshing/Baileys)
* [`Mhankbarbar`](https://github.com/MhankBarBar)
* [`Fadhil Graphy`](https://github.com/MrK4ZUT0)

</p> 
 #sosial media


* [`WhatsApp Admin `](https://wa.me/628990542731)

* [`SIMPLE API `](http://apifdl.eu5.org)


